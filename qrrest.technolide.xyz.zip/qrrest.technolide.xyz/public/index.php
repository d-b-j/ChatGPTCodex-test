<?php
/**
 * QR-Based School Alumnus API - Entry Point
 * 
 * This file serves as the main entry point for all API requests.
 * It handles routing, request parsing, and response dispatch.
 * 
 * PHP Version: 8.0+
 * Author: Development Team
 * Date: 2025
 */

// Enable error reporting for development (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 0); // Log errors instead of displaying
ini_set('log_errors', 1);

// Define application constants
define('APP_ROOT', dirname(__DIR__));
define('SRC_PATH', APP_ROOT . '/src');
define('BASE_URL', '/v1');
define('API_HOST', 'qrrest.technolide.xyz');

// Set content type header
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Autoloader function for PSR-4 style class loading
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    $base_dir = SRC_PATH . '/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Include helper files
require_once SRC_PATH . '/Helpers/Response.php';
require_once SRC_PATH . '/Helpers/Logger.php';
require_once SRC_PATH . '/Helpers/Utils.php';

try {
    // Parse the request URL
    $request_uri = $_SERVER['REQUEST_URI'];
    $base_path = str_replace('/index.php', '', $_SERVER['SCRIPT_NAME']);
    
    // Remove base URL prefix
    if (strpos($request_uri, BASE_URL) === 0) {
        $path = substr($request_uri, strlen(BASE_URL));
    } else {
        $path = $request_uri;
    }

    // Remove query string
    if (($pos = strpos($path, '?')) !== false) {
        $path = substr($path, 0, $pos);
    }

    // Remove trailing slash
    $path = rtrim($path, '/');

    if (empty($path)) {
        $path = '/';
    }

    $method = $_SERVER['REQUEST_METHOD'];

    // Route the request
    routeRequest($method, $path);

} catch (Exception $e) {
    \App\Helpers\Logger::error($e->getMessage(), ['exception' => $e]);
    \App\Helpers\Response::error($e->getMessage(), 500);
}

/**
 * Route the incoming request to the appropriate controller
 * 
 * @param string $method HTTP method (GET, POST, PUT, DELETE)
 * @param string $path   Request path
 * @return void
 */
function routeRequest($method, $path)
{
    // Parse the path to extract resource and ID
    $segments = array_filter(explode('/', $path));
    
    if (empty($segments)) {
        \App\Helpers\Response::error('Invalid request path', 400);
        return;
    }

    $resource = array_shift($segments);
    $id = !empty($segments) ? array_shift($segments) : null;

    // Route based on resource
    switch ($resource) {
        case 'member':
            handleMemberRequest($method, $id);
            break;
        
        case 'health':
            // Health check endpoint
            \App\Helpers\Response::success(['status' => 'OK'], 'API is healthy');
            break;

        default:
            \App\Helpers\Response::error('Resource not found', 404);
            break;
    }
}

/**
 * Handle member-related requests
 * 
 * @param string $method HTTP method
 * @param string|null $id Member ID
 * @return void
 */
function handleMemberRequest($method, $id = null)
{
    // Include necessary files
    require_once SRC_PATH . '/Config/Database.php';
    require_once SRC_PATH . '/Controllers/MemberController.php';

    $controller = new \App\Controllers\MemberController();

    try {
        switch ($method) {
            case 'POST':
                if (!empty($id)) {
                    \App\Helpers\Response::error('Invalid request', 400);
                    return;
                }
                $controller->create();
                break;

            case 'GET':
                if (empty($id)) {
                    \App\Helpers\Response::error('Member ID is required', 400);
                    return;
                }
                $controller->retrieve($id);
                break;

            case 'PUT':
            case 'PATCH':
                if (empty($id)) {
                    \App\Helpers\Response::error('Member ID is required', 400);
                    return;
                }
                $controller->update($id);
                break;

            case 'DELETE':
                if (empty($id)) {
                    \App\Helpers\Response::error('Member ID is required', 400);
                    return;
                }
                $controller->delete($id);
                break;

            default:
                \App\Helpers\Response::error('Method not allowed', 405);
                break;
        }
    } catch (Exception $e) {
        \App\Helpers\Logger::error($e->getMessage(), ['exception' => $e]);
        \App\Helpers\Response::error($e->getMessage(), 500);
    }
}