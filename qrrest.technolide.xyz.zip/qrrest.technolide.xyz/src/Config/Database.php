<?php
/**
 * Database Connection Manager
 * 
 * Manages PDO connections to MySQL database.
 * Implements singleton pattern for connection reuse.
 * 
 * PHP Version: 8.0+
 */

namespace App\Config;

use PDO;
use PDOException;

class Database
{
    /**
     * Singleton instance
     * @var self|null
     */
    private static ?self $instance = null;

    /**
     * PDO connection
     * @var PDO|null
     */
    private ?PDO $connection = null;

    /**
     * Database configuration
     * @var array
     */
    private array $config;

    /**
     * Private constructor to prevent direct instantiation
     */
    private function __construct()
    {
        $this->config = require CONFIG_PATH . '/database.php';
        $this->connect();
    }

    /**
     * Prevent cloning of singleton instance
     */
    private function __clone()
    {
    }

    /**
     * Prevent unserialization of singleton instance
     */
    public function __wakeup()
    {
    }

    /**
     * Get singleton instance
     * 
     * @return self
     */
    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Establish database connection
     * 
     * @return void
     * @throws PDOException
     */
    private function connect(): void
    {
        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                $this->config['host'],
                $this->config['port'],
                $this->config['database'],
                $this->config['charset']
            );

            $this->connection = new PDO(
                $dsn,
                $this->config['username'],
                $this->config['password'],
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );

        } catch (PDOException $e) {
            throw new PDOException('Database connection failed: ' . $e->getMessage());
        }
    }

    /**
     * Get PDO connection instance
     * 
     * @return PDO
     */
    public function getConnection(): PDO
    {
        if ($this->connection === null) {
            $this->connect();
        }
        return $this->connection;
    }

    /**
     * Execute a prepared statement
     * 
     * @param string $sql SQL query
     * @param array $params Bind parameters
     * @return PDOStatement
     * @throws PDOException
     */
    public function prepare(string $sql)
    {
        return $this->getConnection()->prepare($sql);
    }

    /**
     * Close the connection
     * 
     * @return void
     */
    public function closeConnection(): void
    {
        $this->connection = null;
    }
}

// Define config path constant
if (!defined('CONFIG_PATH')) {
    define('CONFIG_PATH', dirname(__DIR__, 2) . '/config');
}